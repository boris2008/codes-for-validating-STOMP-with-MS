install.packages("dplyr")
install.packages("readr")
install.packages("ggplot2")
install.packages("tidyverse")
library(dplyr)
library(readr)
library(ggplot2)
library(tidyverse)
file = "human_protein_hitCount.txt"
keyword ="human"
toxof <- read.delim(file, header = TRUE, sep = "\t", dec = ".")
#toxof <- read.csv(file)
nOfOri= nrow(toxof)

# check if string contains: grepl("hello", "12_hel_lo#@dfe")
rowSE <- function(x){
  # x is a data.frame
  nr<-nrow(x)
  nc<-ncol(x)
  se<-c()
  #convert data.frame to a matrix
  x<-as.matrix(x, rownames.force = NA)
  for (i in 1:nr){
    #extract a row
    a <-x[i,]
    b<- sqrt(sum((a-mean(a))^2/(length(a)-1)))
    se<-c(se,b)
  }
  return(se)
}
spCon1_Ave <- rowMeans(select(toxof, contains("C1_Bo")))
spCon1_se <- rowSE(select(toxof, contains("C1_Bo")))
spIP1_Ave <- rowMeans(select(toxof, contains("IP1_Bo")))
spIP1_se <- rowSE(select(toxof, contains("IP1_Bo")))

spCon2_Ave <- rowMeans(select(toxof, contains("C2_Bo")))
spCon2_se <- rowSE(select(toxof, contains("C2_Bo")))
spIP2_Ave <- rowMeans(select(toxof, contains("IP2_Bo")))
spIP2_se <- rowSE(select(toxof, contains("IP1_Bo")))

toxof <- toxof%>% mutate(con1_ave = spCon1_Ave,con1_se = spCon1_se,ip1_ave =spIP1_Ave, ip1_se=spIP1_se, con2_ave = spCon2_Ave,con2_se = spCon2_se,ip2_ave =spIP2_Ave, ip2_se=spIP2_se)

#clear any protein in the con1 sample with spectral counting >4
toxof <- toxof %>% filter(con1_ave >1)

#get the fold of control STP VS. N
con_fold <- toxof$con1_ave/toxof$con2_ave

fold2score <-function(y){
  #y is a numberic list
  escore <- c()
  for (i in 1:length(y)){
    if (is.infinite(y[i])){
      score = 500
    }
    else if (is.nan(y[i])){
      score = 1
    }
    else if (y[i]< 1 & y[i]>0 ){
      score = -1/y[i]
    }
    else if (y[i]==0){
      score = -500
    }
    else{
      score = y[i]
    }
    escore <- c(escore,score)
  }
  return(escore)
  
}

foldCorrect <-function(y){
  #y is a numberic list
  escore <- c()
  for (i in 1:length(y)){
    if (is.infinite(y[i])){
      score = 500*runif(1,0.5,1) 
    }
    else if (is.nan(y[i])){
      score = 1
    }
    else if (y[i]==0){
      score = 1
    }
    else{
      score = y[i]
    }
    escore <- c(escore,score)
  }
  return(escore)
  
}
con_fold <- foldCorrect(con_fold)
con_escore <- fold2score(con_fold)

#get the fold of IP STP vs N

ip_fold <- toxof$ip1_ave/toxof$ip2_ave
View(ip_fold)
ip_fold <- foldCorrect(ip_fold)
ip_score<- fold2score(ip_fold)

##run t-test
#get the control 1
ctr1 <- toxof%>% select(contains("C1_Bo"))
#intentially add 0.0001 to the column 3 to prevent the idential values shown in each row
ctr1[ncol(ctr1)]<-ctr1[ncol(ctr1)]+1e-6
#convert data.frame to a matrix
ctr1<-as.matrix(ctr1, rownames.force = NA)
#get the control 2
ctr2 <- toxof%>% select(contains("C2_Bo"))
ctr2[ncol(ctr2)]<-ctr2[ncol(ctr2)]+1e-6
ctr2<-as.matrix(ctr2, rownames.force = NA)
#get the ip 1
ip1 <- toxof%>% select(contains("IP1_Bo"))
ip1[ncol(ip1)]<-ip1[ncol(ip1)]+1e-6
ip1<-as.matrix(ip1, rownames.force = NA)
#get the ip 2
ip2 <- toxof%>% select(contains("IP2_Bo"))
ip2[ncol(ip2)]<-ip2[ncol(ip2)]+1e-6
ip2<-as.matrix(ip2, rownames.force = NA)

#define the function of t-test to compare two matrix
ttestMatrix <- function(x,y){
  pVal<-c()
  for (i in 1:nrow(x)){
    #compare matrix x and y
    y1 <-x[i,]
    y2 <-y[i,]+0.00001
    #retrive p-value
    if(mean(y1)> mean(y2)){
      p <-t.test(y1,y2, alternative="greater",var.equal=FALSE, paired=FALSE)$p.value 
    } else {
      p <-t.test(y1,y2, alternative="less",var.equal=FALSE, paired=FALSE)$p.value 
    }
    pVal<-c(pVal,p)
  }
  return(pVal)
}

#'data are essentially constant' error
#it's not possible to estimate confidence intervals and perform t-tests if identical values exist

#run the t test between ctr1 and ctr2
ctrp<-ttestMatrix(ctr1, ctr2)
#run the t test between ip1 and ip2
ipp<-ttestMatrix(ip1, ip2)

toxof <- toxof %>% mutate(ctrfold = con_fold, ctrScore = con_escore, ipfold= ip_fold, ipScore = ip_score,ctr1v2_p =ctrp, ip1v2_p=ipp)
toxof <- toxof%>%filter(ctrScore<1.5 & ctrScore >-1.5)
nOf1<-nrow(toxof)
perOfDataPrsnt <- nOf1/nOfOri
paste(perOfDataPrsnt, " of data presented out of all proteome")
# Write to file
fName <-paste(getwd(),"/",keyword,"-table.csv",sep = "", collapse = NULL)
toxof %>% write_csv(fName)
#get those data with p < 0.05 for IP sample of STOMP VS N
toxofp<- toxof %>% filter(toxof$ip1v2_p<0.05) %>%
  arrange(ip1v2_p)
fN <-paste(getwd(),"/",keyword,"-table_pLessT0.05.csv",sep = "", collapse = NULL)
toxofp %>% write_csv(fN)
###############################################
#plot the toxo IP data of enrichment score____
#################################################
plotdata ="ipfold"
if (grepl('ip', plotdata, fixed=TRUE)){
  plotkey = "IP"
  #ydata = "toxof$ipfold"
}

x=1:nrow(toxof)
ggplot(arrange(toxof,ipScore),aes(x, ipScore)) +
  geom_col(col="cyan",fill ='#56B4E9') +
  aes() + 
  #remove the stupid legend
  guides(fill=FALSE)+
  coord_flip() +
  labs(x="Human Protein", y="Enrichment Score",
       title = paste(plotkey," STOMPed vs NonSTOMPed")) +
  theme(text = element_text(size=20),
        plot.title = element_text(hjust = 0.5))+
  geom_hline(yintercept = 1,linetype=3,size= 1)+
  geom_hline(yintercept = -1,linetype=3,size= 1)+
  ylim(-10,10)
fName1=paste(getwd(),'/','humanProtein_',plotkey,'_sample_S_VS_N.pdf')
ggsave(fName1)
#ggsave(fName1, w=20, h=15)
#_______________________________________________________
################################################
#plot the toxo control data of enrichment score___________
################################################
plotdata ="ctrScore"
if (grepl('ctr', plotdata, fixed=TRUE)){
  plotkey = "Control"
  #ydata = "toxof$ipfold"
}

x=1:nrow(toxof)
ggplot(arrange(toxof,ctrScore),aes(x, ctrScore)) +
  geom_col() +
  aes(fill="red") + 
  #remove the stupid legend
  guides(fill=FALSE)+
  coord_flip() +
  labs(x="Human Protein", y="Enrichment Score",
       title = paste(plotkey," STOMPed vs NonSTOMPed")) +
  theme(text = element_text(size=20),
        plot.title = element_text(hjust = 0.5))+
  geom_hline(yintercept = 1,linetype=3,size= 1)+
  geom_hline(yintercept = -1,linetype=3,size= 1)+
  ylim(-10,10)
fName1=paste(getwd(),'/','humanProtein_',plotkey,'_sample_S_VS_N.jpeg')
ggsave(fName1)
#ggsave(fName1, w=20, h=15)
#_______________________________________________________
###################################
# plot the spectral counting data
#####################################
library(ggplot2)
library(dplyr)
toxof <- toxof%>% arrange(con1_ave)
df1 <- data.frame(x = 1:nrow(toxof),ave = toxof$con1_ave, se=toxof$con1_se)
df2 <- data.frame(x = 1:nrow(toxof),ave = toxof$con2_ave, se=toxof$con2_se)
df3 <- data.frame(x = 1:nrow(toxof),ave = toxof$ip1_ave, se=toxof$ip1_se)
df4 <- data.frame(x = 1:nrow(toxof),ave = toxof$ip2_ave, se=toxof$ip2_se)

df_n <- df1 %>%
  mutate(Type = 'stomp_ctr') %>%
  bind_rows(df2 %>%
              mutate(Type = 'n_ctr')) %>%
  bind_rows(df3 %>%
              mutate(Type = 'stomp_ip')) %>%
  bind_rows(df4 %>%
              mutate(Type = 'n_ip'))

ggplot(df_n, aes(x=x,y=ave,color=Type)) + 
  geom_pointrange(aes(ymin=ave-se, ymax=ave+se))+
  labs(x="Human Protein", y="spectral counting",
       title = paste("Spectral counting","\n","Unique Human proteins","\n","STOMPed vs NonSTOMPed")) +
  theme(text = element_text(size=20),
        plot.title = element_text(hjust = 0.5))

prcnt_ip = 1-nrow(filter(toxof, ip1v2_p <0.05))/nrow(toxof)
paste(prcnt_ip,"% of the total unique human proteins after IP sample are similar between STOMP and Non-STOMP samples")
######################
# create volcano plot
##########################
# p value vs. Score
df1 <- data.frame(ratio = toxof$ipfold, pvalue=toxof$ip1v2_p)
df2 <- data.frame(ratio = toxof$ctrfold, pvalue=toxof$ctr1v2_p)
df_n <- df1 %>%
  mutate(Type = 'IP') %>%
  bind_rows(df2 %>%
              mutate(Type = 'CONTROL'))
#plot the full range
ggplot(df_n)+ geom_point(aes(x= log2(ratio),y = -log10(pvalue), alpha = 0.5, colour = Type))+
  xlab("log2 ratio of STOMP VS. N")+
  ylab("-log10 P value")+
  geom_hline(yintercept = -log10(0.05),linetype=3,size =1)+
  geom_vline(xintercept = 0,linetype=3,size= 1)+
  ggtitle("Volcano plot of unique human proteins")+
  theme(text = element_text(size=20),
        plot.title = element_text(hjust = 0.5))
#zoom in
ggplot(df_n)+ geom_point(aes(x= log2(ratio),y = -log10(pvalue), alpha = 0.5, colour = Type))+
  xlab("log2 ratio of STOMP VS. N")+
  ylab("-log10 P value")+
  geom_hline(yintercept = -log10(0.05),linetype=3,size =1)+
  geom_vline(xintercept = 0,linetype=3,size= 1)+
  ggtitle("Volcano plot of unique human proteins")+
  theme(text = element_text(size=20),
        plot.title = element_text(hjust = 0.5))+
  xlim(-0.8, 0.8)+
  ylim(-0.1,1.4)
#try to use plotrix to add gapped or broken axis to one axis in the plot
library(plotrix)
gap.plot(toxof$ipScore, -log10(toxof$ip1v2_p),gap=c(120,490),gap.axis="x",xlab="Score of STOMP vs.N",
         xtics=c(0,100,120,490,500),ylab="-log10 P value",main="Volcano plot of unique human proteins",col=1,type="p")
gap.plot(toxof$ctrScore,-log10(toxof$ctr1v2_p),gap=c(120,490),gap.axis="x",add=TRUE,col=2,type="p")
legend("center", legend=c("IP", "STOMP"),
       col=c(1,2),lty=c(0,0),cex=1,
       box.lty=1)
